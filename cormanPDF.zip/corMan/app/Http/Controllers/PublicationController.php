<?php

namespace App\Http\Controllers;

use App\Publication;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;


class PublicationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
    	
	$publications = DB::table('publications')
                ->Where(function ($query) {
                $query->where('visibilita', '=', '1');
            })
            ->get();
	$publicationsP = DB::table('publications')
                ->Where(function ($query) {
                $query->where('visibilita', '=', '0')
			->where('idUser', '=', Auth::id());
            })
            ->get();
	
	
	//$publications=Publication::where('idUser', Auth::user()->id)->get();
    	return view('publications.index', ['publications'=>$publications, 'publicationsP'=>$publicationsP]);
    	
    	/*
        $id=Auth::id();
        $publications = DB::table('publications')
            ->select('idPublication', 'titolo', 'dataPubblicazione', 'pdf', 'immagine', 'multimedia', 'tipo', 'tags', 'coautori')
            ->where('idUser', '=', $id)->get();
        return view ('publications.index', ['publications' => $publications]);
        */
		}
		
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('publications.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
         // Create new Profile instance
       // $pub = new Publication();

        // Make sure to validate both field
        // And fill the instance with the validated result
			/*       
        $pub->fill(
            $request->validate([
            'titolo' => 'required|max:255',
            'dataPubblicazione' => '',
            'pdf' => 'mimes:application/pdf, application/x-pdf,application/acrobat, applications/vnd.pdf, text/pdf, text/x-pdf|max:10000',
            'immagine' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'multimedia' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'tipo' => 'required',
            'visibilita' => '',
            'tags' => 'max:255',
            'coautori' => 'max:255',
            'idUser' => ''
            ])
        );
        */
        
        $val = $request->validate([
            'titolo' => 'required|max:255',
            'dataPubblicazione' => '',
            'pdf' => 'mimes:application/pdf, application/x-pdf,application/acrobat, applications/vnd.pdf, text/pdf, text/x-pdf|max:10000',
            'immagine' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'multimedia' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'tipo' => 'required',
            'visibilita' => '',
            'tags' => 'max:255',
            'coautori' => 'max:255',
            'idUser' => ''
        ]);
        if($request['immagine']!=null){
        	
        Publication::create([
            'titolo' => $request['titolo'],
            'dataPubblicazione' => date('Y-m-d H:i:s'),
            'pdf' => $request->file('pdf')->store('pdf'),
            'immagine' =>$request->file('immagine')->store('immagine'),
            'multimedia' => '',
            'tipo' => $request['tipo'],
            'visibilita' => $request['visibilita'],
            'tags' => $request['tags'],
            'coautori' => $request['coautori'],
            'idUser' => Auth::id()
        ]);
        }
        else{
        	Publication::create([
            'titolo' => $request['titolo'],
            'dataPubblicazione' => date('Y-m-d H:i:s'),
            'pdf' => '',
            'immagine' =>'',
            'multimedia' => '',
            'tipo' => $request['tipo'],
            'visibilita' => $request['visibilita'],
            'tags' => $request['tags'],
            'coautori' => $request['coautori'],
            'idUser' => Auth::id()
        ]);
        	
        	
        	
        	
        	
        	
        	
        	
        	}
        // Get the path of the `avatar` and assign it in the avatar column
			    
        //$pub->immagine = $request->file('immagine')->store('immagine');

        // Save it to the database
        //$pub->save();

        // Redirect to the profile
        //return redirect('/profile/'.$profile->id);
        
        
        
        return redirect()->route('home');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $publications=Publication::where('visibilita', 0)->get();
        $this->showPDF('/');
    	return view('publications.index', ['publications'=>$publications]);
    }


    public function altron($pdf)
    {
        //$publications=Publication::where('visibilita', 0)->get();
        
        dump("maritozzo non panciabile225555");
        //return view('home');
        //return response()->file($pdf);


        //return view('publications.index', ['publications'=>$publications]);



    }









    /**
     * Display PDF
     *
     * @param  String  $pdf
     * @return \Illuminate\Http\Response
     */
    

    public function showPDF($pdf)
    {
        //$publications=Publication::where('visibilita', 0)->get();
        dump("executin showPDF");

        dump(response()->file('storage/pdf/mypdf.pdf'));
        //return view('home');
        //$perc=Storage::url($pdf);
        return response()->file('storage/pdf/mypdf.pdf');


        //return view('publications.index', ['publications'=>$publications]);



    }

    



    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $publications = DB::table('publications')
            ->select('idPublication', 'titolo', 'dataPubblicazione', 'pdf', 'immagine', 'multimedia', 'tipo', 'visibilita', 'tags', 'coautori', 'idUser')
            ->where('idPublication', '=', $id)
            ->where('idUser', '=', Auth::id())->get();
        return view('publications.edit', ['publications' => $publications]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $idPublication)
    {
        //$idPublication=$id;
        //save data
        dump($request->file('immagine'));
        
        
        if($request['immagine']!=null){
        
        $pubUpdate=Publication::where('idPublication',$idPublication)->update([
        			
            'pdf' =>$request->file('pdf')->store('pdf'),
            'immagine' =>$request->file('immagine')->store('immagine'),
            'multimedia' => '',
            'tipo' => $request['tipo'],
            'visibilita' => $request['visibilita'],
            'tags' => $request['tags'],
            'coautori' => $request['coautori'],
           
         ]);
        }
        else{
        	$pubUpdate=Publication::where('idPublication',$idPublication)->update([
        			
            'pdf' => $request->file('pdf')->store('pdf'),
            'immagine' =>'',
            'multimedia' => '',
            'tipo' => $request['tipo'],
            'visibilita' => $request['visibilita'],
            'tags' => $request['tags'],
            'coautori' => $request['coautori'],
           
         ]);
        	
        
        
        }
        //redirect
        if($pubUpdate){
        			return redirect()->route('publications.index',['publication'=>$idPublication])->with('success','Publication update succesfully');
        	
        	
        }
        
        return back()->withInput();
        
        
        
        
        
        
        /*$publication=DB::table('publications')->where('idPublication',$idPublication)->update(['titolo' => $request->get('titolo')], ['tipo' => $request->get('tipo')], ['visibilita' => $request->get('visibilita')], ['tags' => $request->get('tags')], ['coautori' => $request->get('coautori')]);
        $this->validate($request, [
            'titolo' => 'required|max:255',
            'dataPubblicazione' => '',
            'pdf' => 'mimes:application/pdf, application/x-pdf,application/acrobat, applications/vnd.pdf, text/pdf, text/x-pdf|max:10000',
            'immagine' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'multimedia' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'tipo' => 'required',
            'visibilita' => '',
            'tags' => 'required',
            'coautori' => 'required',
            'idUser' => ''
        ]);
        return redirect()->route('home');*/
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy()
    {
        dump("destroy");
        //
        
    }
}
