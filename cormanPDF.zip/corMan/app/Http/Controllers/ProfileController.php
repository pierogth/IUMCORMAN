<?php

namespace App\Http\Controllers;
use App\Profile;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function index(Profile $profile)
    {
        // Return the views with all the profile list
        return view('profile.index', [
            'profiles' => $profile->all()
        ]);
    }

    public function show(Profile $profile, $id)
    {
        // Return the views of the requested profile
        return view('profile.show', [
            'profile' => $profile->find($id)
        ]);
    }

    public function create()
    {
        // Return the `create form` views
        return view('profile.create');
    }

    public function store(Request $request)
    {
        // Create new Profile instance
        $profile = new Profile();

        // Make sure to validate both field
        // And fill the instance with the validated result
        $profile->fill(
            $request->validate([
                'name' => 'required',
                'avatar' => 'required'
            ])
        );

        // Get the path of the `avatar` and assign it in the avatar column
        $profile->avatar = $request->file('avatar')->store('avatar');

        // Save it to the database
        $profile->save();

        // Redirect to the profile
        return redirect('/profile/'.$profile->id);
    }
}
