<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGroupspublicationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('groupspublications', function (Blueprint $table) {
            
            
            $table->integer('idUser')->unsigned();
            $table->integer('idGroup')->unsigned();
            $table->integer('idPublication')->unsigned();
            
            $table->foreign('idUser')->references('id')->on('users');
            $table->foreign('idGroup')->references('idGroup')->on('groups');
            $table->foreign('idPublication')->references('idPublication')->on('publications');
            $table->longText('descrizione');
            $table->timestamp('dataoraGP');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('groupspublications');
    }
}
