<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCommentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('comments', function (Blueprint $table) {
            $table->increments('idComment');
            
            $table->integer('idGroup')->unsigned();
            $table->integer('idPublication')->unsigned();
            $table->integer('idUser')->unsigned();            
            
            $table->foreign('idGroup')->references('idGroup')->on('groups');
            $table->foreign('idPublication')->references('idPublication')->on('publications');
            $table->foreign('idUser')->references('id')->on('users');
            $table->longText('descrizione');
            $table->timestamp('dataoraC');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('comments');
    }
}
