

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><br />
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(count($publications) === 1): ?>
                        <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <form method="POST" enctype="multipart/form-data" action="<?php echo e(action('PublicationController@update', [$p->idPublication] )); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e(csrf_field()); ?>

                        <input name="_method" type="hidden" value="PUT">
                        <h2>Your profile details</h2>
                        <ul class="nav nav-tabs">
                            <li><a data-toggle="tab" href="#home">My profile</a></li>
                            <li class="active"><a data-toggle="tab" href="#menu1">My publications</a></li>
                        </ul>
                        <div class="tab-content">
                            <div id="home" class="tab-pane fade">
                                <h3>My profile</h3>
                                <p>
                                    Please, finish uploading your publication details and then come here again. Thank you for your patience!
                                </p>
                            </div>
                            <div id="menu1" class="tab-pane fade in active">
                                <h3>My publications</h3>
                                <p>
                                    <div class="table-responsive">          
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>Publication ID</th>
                                                    <th>Title</th>
                                                    <th>Publication Date</th>
                                                    <th>PDF File</th>
                                                    <th>Image</th>
                                                    <th>Multimedia</th>
                                                    <th>Type of publication</th>
                                                    <th>Paper visibility</th>
                                                    <th>Publication tags</th>
                                                    <th>List of coauthors</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td><?php echo e($p->idPublication); ?></td>
                                                        <td><input class="form-control" id="titolo" name="titolo" type="text" value="<?php echo e($p->titolo); ?>" /></td>
                                                        <td><?php echo e($p->dataPubblicazione); ?></td>
                                                        <td>
                                                        <input type="file" id='pdf' name="pdf" class="custom-file-input" value="<?php echo e($p->pdf); ?>" r>
                                                        </td>
                                                        <td>	
                                                        <input type="file" id='immagine' name="immagine" class="custom-file-input" value="<?php echo e($p->immagine); ?>" r>
                   						 				<span class="custom-file-control"></span></td>
                                                        <td><?php echo e($p->multimedia); ?></td>
                                                        <td><input class="form-control" id="tipo" name="tipo" type="text" value="<?php echo e($p->tipo); ?>" /></td>
                                                        <td>
                                                            <div class="button-group">
                                                                <div class="radio">
                                                                    <label><input type="radio" name="visibilita" value="1" checked="checked">Public</label>
                                                                </div>
                                                                <div class="radio">
                                                                    <label><input type="radio" name="visibilita" value="0">Private</label>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td><input class="form-control" id="tags" name="tags" type="text" value="<?php echo e($p->tags); ?>" /></td>
                                                        <td><input class="form-control" id="coautori" name="coautori" type="text" value="<?php echo e($p->coautori); ?>" /></td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <button class="btn btn-success " name="submit" type="submit">Update</button>
                                    </div>
                                    </p>
                                </p>
                            </div>
                        </div>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>