@extends('layouts.app')

@section('content')
<div class="container">
   
        <div class="col-md-12">
            <div class="panel panel-default">
                
                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                        <h2>Your profile details</h2>
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#home">My profile</a></li>
                            <li><a data-toggle="tab" href="#menu1">My private publications</a></li>
			    <li><a data-toggle="tab" href="#menu2">My public publications</a></li>
                        </ul>
                        <div class="tab-content">
                            <div id="home" class="tab-pane fade in active">
                                <h3>My profile</h3>
                                <p>
                                    <div class="table-responsive">          
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>User ID</th>
                                                    <th>Firstname</th>
                                                    <th>Lastname</th>
                                                    <th>E-mail</th>
                                                    <th>Nationality</th>
                                                    <th>Affiliation</th>
                                                    <th>Research field</th>
                                                    <th>Phone</th>
                                                    <th>Edit your profile</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>{{ Auth::id() }}</td>
                                                    @foreach($users as $u)
                                                        <td>{{ $u->name }}</td>
                                                        <td>{{ $u->cognome }}</td>
                                                        <td>{{ $u->email }}</td>
                                                        <td>{{ $u->nazionalita }}</td>
                                                        <td>{{ $u->affiliazione }}</td>
                                                        <td>{{ $u->linea_ricerca }}</td>
                                                        <td>{{ $u->telefono }}</td>
                                                        <td><a href="{{action('UserController@edit', Auth::id() )}}" class="btn btn-warning">Edit</a></td>
                                                    @endforeach
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </p>
                            </div>
			    
			    
			    
			    <div id="menu1" class="tab-pane fade">   <a href="{{action('PublicationController@create')}}" class="btn btn-default pull-right">Create a new Paper</a>
                                <h3>My private publications</h3>
                                 <div class="tab-content">
				                        
				@if(count($publicationsP)>0)
                            <div class="table-responsive">          
                                <table class="table">
                                    <thead>
                                        <tr>
                                            
                                            <th>Publication ID</th>
                                            <th>Title</th>
                                            <th>Publication date</th>
                                            <th>PDF file</th>
                                            <th>Image</th>
                                            <th>Multimedia</th>
                                            <th>Type of publication</th>
                                            <th>Publication Tags</th>
                                            <th>List of coauthors</th>
                                            <th>Edit your paper</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($publicationsP as $p)
                                            <tr>
                                                <td>{{ $p->idPublication }}</td>
                                                <td>{{ $p->titolo }}</td>
                                                <td>{{ $p->dataPubblicazione }}</td>
                                                <td>{{ $p->pdf }}</td>
                                                <td><img src="{{ Storage::url($p->immagine) }}"  class="img-circle" width="50" height="20">   </td></td>
                                                <td>{{ $p->multimedia }}</td>
                                                <td>{{ $p->tipo }}</td>
                                                <td>{{ $p->tags }}</td>
                                                <td>{{ $p->coautori }}</td>
                                                <td><a href="{{action('PublicationController@edit', [$p->idPublication] )}}" class="btn btn-warning">Edit</a></td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @else
                            <strong>We're sorry, but you have never added a paper regarding your research field that you wrote...</strong><br><br>
                            But, if you want, you can add a new one bor importing it from DBLP by simply pressing one of the buttons below!<br><br>
                            <a href="{{action('PublicationController@create')}}" class="btn btn-info">Create a new paper</a>
                            <button type="button" class="btn btn-info">Import my researchs from DBLP</button>
                        @endif
                    </div>
			
				<p>
                                    See all my private publications <a href="{{action('PublicationController@show', 1)}}"> here</a>.<br>
                                    Or, create a new one <a href="{{action('PublicationController@create')}}">here</a>.
                                </p>
                            </div>
                            <div id="menu2" class="tab-pane fade">   <a href="{{action('PublicationController@create')}}" class="btn btn-default pull-right">Create a new Paper</a>
                                <h3>My public publications</h3>  
			 <div class="tab-content">
                        @if(count($publications)>0)
                            <div class="table-responsive">          
                                <table class="table">
                                    <thead>
                                        <tr>
                                            
                                            <th>Publication ID</th>
                                            <th>Title</th>
                                            <th>Publication date</th>
                                            <th>PDF file</th>
                                            <th>Image</th>
                                            <th>Multimedia</th>
                                            <th>Type of publication</th>
                                            <th>Publication Tags</th>
                                            <th>List of coauthors</th>
                                            <th>Edit your paper</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($publications as $p)
                                            <tr>
                                                <td>{{ $p->idPublication }}</td>
                                                <td>{{ $p->titolo }}</td>
                                                <td>{{ $p->dataPubblicazione }}</td>
                                                <td>{{ $p->pdf }}</td>
                                                <td><img src="{{ Storage::url($p->immagine) }}"  class="img-circle" width="50" height="20">   </td></td>
                                                <td>{{ $p->multimedia }}</td>
                                                <td>{{ $p->tipo }}</td>
                                                <td>{{ $p->tags }}</td>
                                                <td>{{ $p->coautori }}</td>
                                                <td><a href="{{action('PublicationController@edit', [$p->idPublication] )}}" class="btn btn-warning">Edit</a></td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @else
                            <strong>We're sorry, but you have never added a paper regarding your research field that you wrote...</strong><br><br>
                            But, if you want, you can add a new one bor importing it from DBLP by simply pressing one of the buttons below!<br><br>
                            <a href="{{action('PublicationController@create')}}" class="btn btn-info">Create a new paper</a>
                            <button type="button" class="btn btn-info">Import my researchs from DBLP</button>
                        @endif
                    </div>


                                <p>
                                    See all my public publications <a href="{{action('PublicationController@index')}}"> here</a>.<br>
                                    Or, create a new one <a href="{{action('PublicationController@create')}}">here</a>.
                                </p>
                            </div>
                        </div>
                        </div>
                </div>
            </div>
        
    </div>

@endsection

