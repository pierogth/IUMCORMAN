

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Attività recenti</div>
                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                        <h2>Your profile details</h2>
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#home">My profile</a></li>
                            <li><a data-toggle="tab" href="#menu1">My publications</a></li>
                        </ul>
                        <div class="tab-content">
                            <div id="home" class="tab-pane fade in active">
                                <h3>My profile</h3>
                                <p>
                                    <div class="table-responsive">          
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <th>User ID</th>
                                                    <th>Firstname</th>
                                                    <th>Lastname</th>
                                                    <th>E-mail</th>
                                                    <th>Nationality</th>
                                                    <th>Affiliation</th>
                                                    <th>Research field</th>
                                                    <th>Phone</th>
                                                    <th>Edit your profile</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><?php echo e(Auth::id()); ?></td>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td><?php echo e($u->name); ?></td>
                                                        <td><?php echo e($u->cognome); ?></td>
                                                        <td><?php echo e($u->email); ?></td>
                                                        <td><?php echo e($u->nazionalita); ?></td>
                                                        <td><?php echo e($u->affiliazione); ?></td>
                                                        <td><?php echo e($u->linea_ricerca); ?></td>
                                                        <td><?php echo e($u->telefono); ?></td>
                                                        <td><a href="<?php echo e(action('UserController@edit', Auth::id() )); ?>" class="btn btn-warning">Edit</a></td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </p>
                            </div>
                            <div id="menu1" class="tab-pane fade">
                                <h3>My publications</h3>
                                <p>
                                    See all my publications <a href="<?php echo e(action('PublicationController@index')); ?>"> here</a>.<br>
                                    Or, create a new one <a href="<?php echo e(action('PublicationController@create')); ?>">here</a>.
                                </p>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>