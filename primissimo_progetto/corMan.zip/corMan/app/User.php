<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'name',
        'cognome',
        'email',
        'nazionalita',
        'affiliazione',
        'linea_ricerca',
        'telefono',
        'password'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
    
	 public function publications(){
	 	
	 	return $this->hasMany('app/Publication');    
    
		}
		
	public function comments(){
	 	
	 	return $this->hasMany('app/Comment');    
    
		}
		
	public function groups(){
	 	
	 	return $this->belongsToMany('app/Group');    
    
		}
	}
